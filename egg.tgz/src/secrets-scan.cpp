// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("secrets scan\n", stdout);
  return lionss_run_workload("secrets-scan");
}
