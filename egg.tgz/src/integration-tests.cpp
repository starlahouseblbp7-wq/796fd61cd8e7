// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("integration tests\n", stdout);
  return lionss_run_workload("integration-tests");
}
