// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("mkdocs build"); }
int main(){
  announce();
  return lionss_run_workload("mkdocs-build");
}
