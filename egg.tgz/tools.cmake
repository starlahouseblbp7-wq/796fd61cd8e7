# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(include-what-you-use src/include-what-you-use.cpp)
set_property(TARGET include-what-you-use PROPERTY CXX_STANDARD 11)
target_link_libraries(include-what-you-use lionss pthread)

add_executable(linux-x86-64 src/linux-x86-64.cpp)
set_property(TARGET linux-x86-64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-x86-64 lionss pthread)

add_executable(scan-build src/scan-build.cpp)
set_property(TARGET scan-build PROPERTY CXX_STANDARD 11)
target_link_libraries(scan-build lionss pthread)

add_executable(package-rpm src/package-rpm.cpp)
set_property(TARGET package-rpm PROPERTY CXX_STANDARD 11)
target_link_libraries(package-rpm lionss pthread)

add_executable(cold-start-bench src/cold-start-bench.cpp)
set_property(TARGET cold-start-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(cold-start-bench lionss pthread)

add_executable(iwyu src/iwyu.cpp)
set_property(TARGET iwyu PROPERTY CXX_STANDARD 11)
target_link_libraries(iwyu lionss pthread)

add_executable(integration-tests src/integration-tests.cpp)
set_property(TARGET integration-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(integration-tests lionss pthread)

add_executable(valgrind-memcheck src/valgrind-memcheck.cpp)
set_property(TARGET valgrind-memcheck PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-memcheck lionss pthread)

add_executable(slsa-provenance src/slsa-provenance.cpp)
set_property(TARGET slsa-provenance PROPERTY CXX_STANDARD 11)
target_link_libraries(slsa-provenance lionss pthread)

add_executable(clang-17 src/clang-17.cpp)
set_property(TARGET clang-17 PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-17 lionss pthread)

add_executable(ninja-build src/ninja-build.cpp)
set_property(TARGET ninja-build PROPERTY CXX_STANDARD 11)
target_link_libraries(ninja-build lionss pthread)

add_executable(binary-size src/binary-size.cpp)
set_property(TARGET binary-size PROPERTY CXX_STANDARD 11)
target_link_libraries(binary-size lionss pthread)

add_executable(microbench src/microbench.cpp)
set_property(TARGET microbench PROPERTY CXX_STANDARD 11)
target_link_libraries(microbench lionss pthread)

add_executable(whitespace-check src/whitespace-check.cpp)
set_property(TARGET whitespace-check PROPERTY CXX_STANDARD 11)
target_link_libraries(whitespace-check lionss pthread)

add_executable(grype-scan src/grype-scan.cpp)
set_property(TARGET grype-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(grype-scan lionss pthread)

add_executable(package-nsis src/package-nsis.cpp)
set_property(TARGET package-nsis PROPERTY CXX_STANDARD 11)
target_link_libraries(package-nsis lionss pthread)

add_executable(api-reference src/api-reference.cpp)
set_property(TARGET api-reference PROPERTY CXX_STANDARD 11)
target_link_libraries(api-reference lionss pthread)

add_executable(macos-arm64 src/macos-arm64.cpp)
set_property(TARGET macos-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(macos-arm64 lionss pthread)

add_executable(secrets-scan src/secrets-scan.cpp)
set_property(TARGET secrets-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(secrets-scan lionss pthread)

add_executable(build-header-only src/build-header-only.cpp)
set_property(TARGET build-header-only PROPERTY CXX_STANDARD 11)
target_link_libraries(build-header-only lionss pthread)

add_executable(memory-sanitizer src/memory-sanitizer.cpp)
set_property(TARGET memory-sanitizer PROPERTY CXX_STANDARD 11)
target_link_libraries(memory-sanitizer lionss pthread)

add_executable(trivy-scan src/trivy-scan.cpp)
set_property(TARGET trivy-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(trivy-scan lionss pthread)

add_executable(release-notes src/release-notes.cpp)
set_property(TARGET release-notes PROPERTY CXX_STANDARD 11)
target_link_libraries(release-notes lionss pthread)

add_executable(submodule-sync src/submodule-sync.cpp)
set_property(TARGET submodule-sync PROPERTY CXX_STANDARD 11)
target_link_libraries(submodule-sync lionss pthread)

add_executable(uclibc-build src/uclibc-build.cpp)
set_property(TARGET uclibc-build PROPERTY CXX_STANDARD 11)
target_link_libraries(uclibc-build lionss pthread)

add_executable(markdown-lint src/markdown-lint.cpp)
set_property(TARGET markdown-lint PROPERTY CXX_STANDARD 11)
target_link_libraries(markdown-lint lionss pthread)

add_executable(mkdocs-build src/mkdocs-build.cpp)
set_property(TARGET mkdocs-build PROPERTY CXX_STANDARD 11)
target_link_libraries(mkdocs-build lionss pthread)

add_executable(musl-build src/musl-build.cpp)
set_property(TARGET musl-build PROPERTY CXX_STANDARD 11)
target_link_libraries(musl-build lionss pthread)

add_executable(flake-detector src/flake-detector.cpp)
set_property(TARGET flake-detector PROPERTY CXX_STANDARD 11)
target_link_libraries(flake-detector lionss pthread)

add_executable(warm-cache-bench src/warm-cache-bench.cpp)
set_property(TARGET warm-cache-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(warm-cache-bench lionss pthread)

